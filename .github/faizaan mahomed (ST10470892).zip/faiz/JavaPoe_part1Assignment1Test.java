/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.javapoe_part1assignment1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class JavaPoe_part1Assignment1Test {

    @Test
    public void testValidUsername() {
        assertTrue(JavaPoe_part1Assignment1.checkUserName("abc_1"));
    }

    @Test
    public void testInvalidUsername() {
        assertFalse(JavaPoe_part1Assignment1.checkUserName("abcdef"));
    }

    @Test
    public void testValidPassword() {
        // Meets all requirements: capital letter, number, special character, and length
        assertTrue(JavaPoe_part1Assignment1.checkPasswordComplexity("Secure@123"));
    }

    @Test
    public void testInvalidPassword() {
        // Too simple: no capital letter, no number, no special character, too short
        assertFalse(JavaPoe_part1Assignment1.checkPasswordComplexity("password"));
    }

    @Test
    public void testValidCellphone() {
        assertTrue(JavaPoe_part1Assignment1.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testInvalidCellphone() {
        assertFalse(JavaPoe_part1Assignment1.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testLoginSuccess() {
        JavaPoe_part1Assignment1.registeredUsername = "abc_1";
        JavaPoe_part1Assignment1.registeredPassword = "Secure@123";
        assertTrue(JavaPoe_part1Assignment1.loginUserMock("abc_1", "Secure@123"));
    }

    @Test
    public void testLoginFail() {
        JavaPoe_part1Assignment1.registeredUsername = "abc_1";
        JavaPoe_part1Assignment1.registeredPassword = "Secure@123";
        assertFalse(JavaPoe_part1Assignment1.loginUserMock("wrongUser", "wrongPass"));
    }

    @Test
    public void testLoginMessageSuccess() {
        String message = JavaPoe_part1Assignment1.returnLoginStatus(true, "John", "Doe");
        assertEquals("Welcome John, Doe it is great to see you again.", message);
    }

    @Test
    public void testLoginMessageFail() {
        String message = JavaPoe_part1Assignment1.returnLoginStatus(false, "John", "Doe");
        assertEquals("Username or password incorrect, please try again.", message);
    }
}
    