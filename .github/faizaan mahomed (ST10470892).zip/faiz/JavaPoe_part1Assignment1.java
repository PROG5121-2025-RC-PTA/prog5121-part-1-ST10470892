/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javapoe_part1assignment1;
import java.util.Scanner;

public class JavaPoe_part1Assignment1 {


    static String registeredUsername;
    static String registeredPassword;
    static String registeredCellphone;
    static String firstName;
    static String lastName;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //User Registration 
        System.out.println(" User Registration ");

        System.out.print("Enter your first name: ");
        firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        lastName = scanner.nextLine();

        registerUser(scanner);

        //User Login
        boolean loginSuccess = loginUser(scanner);
        System.out.println(returnLoginStatus(loginSuccess, firstName, lastName));

        scanner.close();
    }

    public static void registerUser(Scanner scanner) {
        System.out.print("Enter username: ");
        registeredUsername = scanner.nextLine();

        if (!checkUserName(registeredUsername)) {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
        } else {
            System.out.println("Username successfully captured.");
        }

        System.out.print("Enter password: ");
        registeredPassword = scanner.nextLine();

        if (!checkPasswordComplexity(registeredPassword)) {
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
        } else {
            System.out.println("Password successfully captured.");
        }

        System.out.print("Enter cellphone number (e.g. +27831234567): ");
        registeredCellphone = scanner.nextLine();

        if (!checkCellPhoneNumber(registeredCellphone)) {
            System.out.println("Cell number is incorrectly formatted or does not contain an international code, please correct the number and try again.");
        } else {
            System.out.println("Cell number successfully captured.");
        }
    }

    public static boolean loginUser(Scanner scanner) {
        System.out.println("\n=== User Login ===");

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        return username.equals(registeredUsername) && password.equals(registeredPassword);
    }

    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public static boolean checkPasswordComplexity(String password) {
        boolean isLongEnough = password.length() >= 8;
        boolean hasCapital = password.matches(".[A-Z].");
        boolean hasNumber = password.matches(".\\d.");
        boolean hasSpecial = password.matches(".[!@#$%^&()_+\\-={}\\:;\"'<>,.?/].*");

        return isLongEnough && hasCapital && hasNumber && hasSpecial;
    }

    public static boolean checkCellPhoneNumber(String cellphone) {
        return cellphone.matches("\\+27\\d{9}");
    }

    public static String returnLoginStatus(boolean loginSuccess, String firstName, String lastName) {
        if (loginSuccess) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Used in JUnit testing
    public static boolean loginUserMock(String username, String password) {
        return username.equals(registeredUsername) && password.equals(registeredPassword);
    }
}