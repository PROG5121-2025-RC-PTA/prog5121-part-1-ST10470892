/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.java_assignment1part2;

import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
import javax.swing.JOptionPane;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class java_assignment1part2 {

    static String registeredUsername;
    static String registeredPassword;
    static String registeredCellphone;
    static String firstName;
    static String lastName;

    static List<Message> messages = new ArrayList<>();
    static List<Message> sentMessages = new ArrayList<>();
    static List<Message> disregardedMessages = new ArrayList<>();
    static List<Message> storedMessages = new ArrayList<>();
    static List<String> messageHashes = new ArrayList<>();
    static List<String> messageIDs = new ArrayList<>();

    static int totalMessages = 0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Registration
        System.out.println(" User Registration ");
        System.out.print("Enter your first name: ");
        firstName = scanner.nextLine();
        System.out.print("Enter your last name: ");
        lastName = scanner.nextLine();
        registerUser(scanner);

        // Login
        boolean loginSuccess = loginUser(scanner);
        System.out.println(returnLoginStatus(loginSuccess, firstName, lastName));

        if (loginSuccess) {
            System.out.println("\nWelcome to QuickChat.");
            System.out.print("How many messages would you like to send? ");
            int numberOfMessages = Integer.parseInt(scanner.nextLine());

            for (int i = 0; i < numberOfMessages; i++) {
                Message msg = new Message();
                msg.captureMessage(scanner);
                messages.add(msg);
                messageHashes.add(msg.messageHash);
                messageIDs.add(msg.messageID);
                totalMessages++;
            }

            displayMenu(scanner);
        }

        scanner.close();
    }

    public static void displayMenu(Scanner scanner) {
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1 - Display all sent messages (sender and recipient)");
            System.out.println("2 - Display the longest sent message");
            System.out.println("3 - Search message by ID");
            System.out.println("4 - Search messages by recipient");
            System.out.println("5 - Delete message by hash");
            System.out.println("6 - Display full report of sent messages");
            System.out.println("7 - Read stored messages from JSON");
            System.out.println("0 - Exit");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    for (Message m : sentMessages) {
                        System.out.println("Sender: " + firstName + " " + lastName);
                        System.out.println("Recipient: " + m.recipient);
                        System.out.println();
                    }
                    break;
                case "2":
                    Message longest = null;
                    for (Message m : sentMessages) {
                        if (longest == null || m.messageText.length() > longest.messageText.length()) {
                            longest = m;
                        }
                    }
                    if (longest != null) {
                        System.out.println("Longest Message:");
                        System.out.println(longest.messageText);
                    }
                    break;
                case "3":
                    System.out.print("Enter Message ID to search: ");
                    String searchID = scanner.nextLine();
                    for (Message m : sentMessages) {
                        if (m.messageID.equals(searchID)) {
                            System.out.println("Recipient: " + m.recipient);
                            System.out.println("Message: " + m.messageText);
                        }
                    }
                    break;
                case "4":
                    System.out.print("Enter recipient number to search: ");
                    String searchRec = scanner.nextLine();
                    for (Message m : sentMessages) {
                        if (m.recipient.equals(searchRec)) {
                            System.out.println("Message: " + m.messageText);
                        }
                    }
                    break;
                case "5":
                    System.out.print("Enter message hash to delete: ");
                    String hash = scanner.nextLine();
                    for (int i = 0; i < sentMessages.size(); i++) {
                        if (sentMessages.get(i).messageHash.equalsIgnoreCase(hash)) {
                            sentMessages.remove(i);
                            messageHashes.remove(hash);
                            System.out.println("Message deleted.");
                            break;
                        }
                    }
                    break;
                case "6":
                    for (Message m : sentMessages) {
                        System.out.println(m.printMessageDetails());
                        System.out.println();
                    }
                    break;
                case "7":
                    readStoredMessagesFromJSON();
                    break;
                case "0":
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    public static void registerUser(Scanner scanner) {
        System.out.print("Enter username: ");
        registeredUsername = scanner.nextLine();
        if (!checkUserName(registeredUsername)) {
            System.out.println("Username is not correctly formatted.");
        } else {
            System.out.println("Username successfully captured.");
        }

        System.out.print("Enter password: ");
        registeredPassword = scanner.nextLine();
        if (!checkPasswordComplexity(registeredPassword)) {
            System.out.println("Password is not correctly formatted.");
        } else {
            System.out.println("Password successfully captured.");
        }

        System.out.print("Enter cellphone number (e.g. +27831234567): ");
        registeredCellphone = scanner.nextLine();
        if (!checkCellPhoneNumber(registeredCellphone)) {
            System.out.println("Cell number is incorrectly formatted.");
        } else {
            System.out.println("Cell number successfully captured.");
        }
    }

    public static boolean loginUser(Scanner scanner) {
        System.out.println("\n=== User Login ===");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        return username.equals(registeredUsername) && password.equals(registeredPassword);
    }

    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public static boolean checkPasswordComplexity(String password) {
        boolean isLongEnough = password.length() >= 8;
        boolean hasCapital = password.matches(".[A-Z].");
        boolean hasNumber = password.matches(".\\d.");
        boolean hasSpecial = password.matches(".[!@#$%^&()].*");
        return isLongEnough && hasCapital && hasNumber && hasSpecial;
    }

    public static boolean checkCellPhoneNumber(String cellphone) {
        return cellphone.matches("\\+27\\d{9}");
    }

    public static String returnLoginStatus(boolean loginSuccess, String firstName, String lastName) {
        return loginSuccess ? "Welcome " + firstName + ", " + lastName + " it is great to see you again."
                : "Username or password incorrect, please try again.";
    }

    public static void readStoredMessagesFromJSON() {
        try (BufferedReader reader = new BufferedReader(new FileReader("messages.json"))) {
            String line;
            JSONParser parser = new JSONParser();
            while ((line = reader.readLine()) != null) {
                JSONArray array = (JSONArray) parser.parse(line);
                for (Object obj : array) {
                    JSONObject message = (JSONObject) obj;
                    System.out.println("Message ID: " + message.get("MessageID"));
                    System.out.println("Message Hash: " + message.get("MessageHash"));
                    System.out.println("Recipient: " + message.get("Recipient"));
                    System.out.println("Message: " + message.get("Message"));
                    System.out.println();
                }
            }
        } catch (Exception e) {
            System.out.println("Error reading JSON file: " + e.getMessage());
        }
    }

    static class Message {
        String messageID;
        String recipient;
        String messageText;
        String messageHash;

        public void captureMessage(Scanner scanner) {
            this.messageID = generateMessageID();
            System.out.print("Enter recipient phone number (e.g. +27831234567): ");
            this.recipient = scanner.nextLine();

            while (!checkRecipientCell(this.recipient)) {
                System.out.println("Invalid phone number. Please use the +27 format.");
                this.recipient = scanner.nextLine();
            }

            System.out.print("Enter your message (max 250 characters): ");
            this.messageText = scanner.nextLine();

            if (this.messageText.length() > 250) {
                System.out.println("Message too long.");
                return;
            }

            createMessageHash();
            JOptionPane.showMessageDialog(null, printMessageDetails());
            sentMessage(scanner);
            storeMessage();
        }

        private String generateMessageID() {
            Random rand = new Random();
            return String.valueOf(1000000000 + rand.nextInt(900000000));
        }

        public boolean checkRecipientCell(String cell) {
            return cell.matches("\\+27\\d{9}");
        }

        public void createMessageHash() {
            String[] words = messageText.trim().split("\\s+");
            String firstWord = words.length > 0 ? words[0] : "";
            String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
            this.messageHash = messageID.substring(0, 2) + ":" + java_assignment1part2.totalMessages + ":" + firstWord + lastWord;
            this.messageHash = this.messageHash.toUpperCase();
        }

        public void sentMessage(Scanner scanner) {
            System.out.println("Choose an option:");
            System.out.println("1 - Send Message");
            System.out.println("2 - Disregard Message");
            System.out.println("3 - Store Message to send later");
            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    System.out.println("Message sent.");
                    sentMessages.add(this);
                    break;
                case 2:
                    System.out.println("Message disregarded.");
                    disregardedMessages.add(this);
                    break;
                case 3:
                    System.out.println("Message stored for later.");
                    storedMessages.add(this);
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }

        public String printMessageDetails() {
            return "Message ID: " + messageID +
                    "\nMessage Hash: " + messageHash +
                    "\nRecipient: " + recipient +
                    "\nMessage: " + messageText;
        }

        public void storeMessage() {
            JSONObject messageObject = new JSONObject();
            messageObject.put("MessageID", messageID);
            messageObject.put("MessageHash", messageHash);
            messageObject.put("Recipient", recipient);
            messageObject.put("Message", messageText);

            JSONArray messageArray = new JSONArray();
            messageArray.add(messageObject);

            try (FileWriter file = new FileWriter("messages.json", true)) {
                file.write(messageArray.toJSONString());
                file.write(System.lineSeparator());
                file.flush();
                System.out.println("Message saved to JSON file.");
            } catch (IOException e) {
                System.out.println("Error writing to JSON file.");
            }
        }
    }
}