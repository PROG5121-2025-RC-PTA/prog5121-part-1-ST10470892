 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.java_assignment1part2;

package com.mycompany.java_assignment1part2;

import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;

import static junit.framework.Assert.assertTrue;

public class java_assignment1part2Test {

    private Message msg1, msg2, msg3, msg4, msg5;

    @Before
    public void setUp() {
        // Clear arrays before each test
        java_assignment1part2.sentMessages.clear();
        java_assignment1part2.storedMessages.clear();
        java_assignment1part2.disregardedMessages.clear();

        // Test Message 1: Sent
        msg1 = new Message();
        msg1.messageID = "1000000001";
        msg1.recipient = "+27834557896";
        msg1.messageText = "Did you get the cake?";
        msg1.createMessageHash();
        java_assignment1part2.sentMessages.add(msg1);

        // Test Message 2: Stored
        msg2 = new Message();
        msg2.messageID = "1000000002";
        msg2.recipient = "+27838884567";
        msg2.messageText = "Where are you? You are late! I have asked you to be on time.";
        msg2.createMessageHash();
        java_assignment1part2.storedMessages.add(msg2);

        // Test Message 3: Disregarded
        msg3 = new Message();
        msg3.messageID = "1000000003";
        msg3.recipient = "+27834484567";
        msg3.messageText = "Yohoooo, I am at your gate.";
        msg3.createMessageHash();
        java_assignment1part2.disregardedMessages.add(msg3);

        // Test Message 4: Invalid number but Sent
        msg4 = new Message();
        msg4.messageID = "1000000004";
        msg4.recipient = "0838884567";
        msg4.messageText = "It is dinner time!";
        msg4.createMessageHash();
        java_assignment1part2.sentMessages.add(msg4);

        // Test Message 5: Stored
        msg5 = new Message();
        msg5.messageID = "1000000005";
        msg5.recipient = "+27838884567";
        msg5.messageText = "Ok, I am leaving without you.";
        msg5.createMessageHash();
        java_assignment1part2.storedMessages.add(msg5);
    }

    // --------------------- MAIN APP TESTS ---------------------

    @Test
    public void testMain() {
        java_assignment1part2.main(new String[]{});
    }

    @Test
    public void testRegisterUser() {
        Scanner scanner = new Scanner("Test\nUser\nStrongPass1!\n+27831234567\n");
        java_assignment1part2.registerUser(scanner);
    }

    @Test
    public void testLoginUser() {
        Scanner scanner = new Scanner("username\npassword\n");
        boolean result = java_assignment1part2.loginUser(scanner);
        assertFalse(result); // assuming wrong credentials for now
    }

    @Test
    public void testCheckUserName() {
        assertTrue(java_assignment1part2.checkUserName("User_123"));
        assertFalse(java_assignment1part2.checkUserName("Invalid User"));
    }

    @Test
    public void testCheckPasswordComplexity() {
        assertTrue(java_assignment1part2.checkPasswordComplexity("Password123!"));
        assertFalse(java_assignment1part2.checkPasswordComplexity("123"));
    }

    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(java_assignment1part2.checkCellPhoneNumber("+27831234567"));
        assertFalse(java_assignment1part2.checkCellPhoneNumber("123456"));
    }

    @Test
    public void testReturnLoginStatus() {
        String successMsg = java_assignment1part2.returnLoginStatus(true, "Alice", "Smith");
        assertEquals("Welcome Alice Smith, it is great to see you again!", successMsg);

        String failMsg = java_assignment1part2.returnLoginStatus(false, "Bob", "Jones");
        assertEquals("Username or password incorrect, please try again.", failMsg);
    }

    // --------------------- MESSAGE CLASS TESTS ---------------------

    @Test
    public void testRecipientValidation() {
        Message msg = new Message();
        assertTrue(msg.checkRecipientCell("+27834557896"));
    }

    @Test
    public void testMessageLengthWithinLimit() {
        Message msg = new Message();
        msg.messageText = "This is a test message under 250 characters.";
        assertTrue(msg.messageText.length() <= 250);
    }

    @Test
    public void testMessageHashCreation() {
        Message msg = new Message();
        msg.messageID = "1234567890";
        java_assignment1part2.totalMessages = 1;
        msg.messageText = "Did you get the cake?";
        msg.createMessageHash();
        assertEquals("12:1:DIDCAKE", msg.messageHash);
    }

    @Test
    public void testSendMessageAddsToSentMessages() {
        java_assignment1part2.sentMessages.clear();
        Message msg = new Message();
        msg.messageID = "1234567890";
        msg.recipient = "+27834557896";
        msg.messageText = "Hello!";
        msg.createMessageHash();
        java_assignment1part2.sentMessages.add(msg);
        assertTrue(java_assignment1part2.sentMessages.contains(msg));
    }

    @Test
    public void testSentMessagesArrayPopulated() {
        assertEquals(2, java_assignment1part2.sentMessages.size());
        assertEquals("Did you get the cake?", java_assignment1part2.sentMessages.get(0).messageText);
    }

    @Test
    public void testStoredMessagesArrayPopulated() {
        assertEquals(2, java_assignment1part2.storedMessages.size());
    }

    @Test
    public void testDisplayLongestMessage() {
        Message longest = null;
        for (Message m : java_assignment1part2.sentMessages) {
            if (longest == null || m.messageText.length() > longest.messageText.length()) {
                longest = m;
            }
        }
        assertEquals("It is dinner time!", longest.messageText);
    }

    @Test
    public void testSearchByMessageID() {
        String searchID = "1000000001";
        Message found = null;
        for (Message m : java_assignment1part2.sentMessages) {
            if (m.messageID.equals(searchID)) {
                found = m;
            }
        }
        assertNotNull(found);
        assertEquals("Did you get the cake?", found.messageText);
    }

    @Test
    public void testSearchByRecipient() {
        List<String> foundMessages = new ArrayList<>();
        for (Message m : java_assignment1part2.storedMessages) {
            if (m.recipient.equals("+27838884567")) {
                foundMessages.add(m.messageText);
            }
        }
        assertTrue(foundMessages.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(foundMessages.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteByMessageHash() {
        String hashToDelete = msg4.messageHash;
        boolean deleted = java_assignment1part2.sentMessages.removeIf(m -> m.messageHash.equals(hashToDelete));
        assertTrue(deleted);
        assertEquals(1, java_assignment1part2.sentMessages.size());
    }

    @Test
    public void testDisplayReport() {
        Message m = java_assignment1part2.sentMessages.get(0);
        String report = m.printMessageDetails();
        assertTrue(report.contains("Message Hash"));
        assertTrue(report.contains("Recipient"));
        assertTrue(report.contains("Message"));
    }
}